在提交Issue之前请先回答下面问题，谢谢！

1.你是怎么操作的？

尽量把你的操作过程描述清楚，最好能够复现问题。

2.你期望的结果是什么？

3.实际上你得到的结果是什么？

4.你使用的是哪个版本的WeiboSpider? 你的操作系统是什么？是否有读本项目的[常见问题](https://github.com/SpiderClub/weibospider/wiki/%E9%A1%B9%E7%9B%AE%E4%BD%BF%E7%94%A8%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98)？