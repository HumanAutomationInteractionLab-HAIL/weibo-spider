weibospider is written and maintained by Resolvewang and
various contributors:

Development Lead
````````````````

- Resolvewang <resolvewang@foxmail.com>


Patches and Suggestions
```````````````````````

- `yun17 <https://github.com/yun17>`_
- `comwrg <https://github.com/comwrg>`_
- `Lifeistrange <https://github.com/Lifeistrange>`_
- `mwangxx0129 <https://github.com/mwangxx0129>`_
- `60ke <https://github.com/60ke>`_
- Lijian
- `545314690 <https://github.com/545314690>`_
