from django.apps import AppConfig


class WeiboDataConfig(AppConfig):
    name = 'weibo_data'
    verbose_name = '微博数据'