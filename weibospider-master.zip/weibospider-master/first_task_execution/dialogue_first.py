import sys

sys.path.append('.')
sys.path.append('..')

from tasks import execute_dialogue_task

if __name__ == '__main__':
    execute_dialogue_task()
