import sys

sys.path.append('.')
sys.path.append('..')

from tasks import execute_repost_task

if __name__ == '__main__':
    execute_repost_task()
