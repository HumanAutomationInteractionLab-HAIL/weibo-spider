import sys

sys.path.append('.')
sys.path.append('..')

from tasks import execute_search_task

if __name__ == '__main__':
    execute_search_task()
