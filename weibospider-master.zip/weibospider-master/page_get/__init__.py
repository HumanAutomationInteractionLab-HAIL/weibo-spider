from .basic import get_page
from .status import get_cont_of_weibo
from .user import (
    get_profile, get_fans_or_followers_ids)