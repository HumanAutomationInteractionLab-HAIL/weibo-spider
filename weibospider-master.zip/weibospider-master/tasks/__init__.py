from .comment import execute_comment_task
from .home import execute_home_task
from .login import execute_login_task
from .repost import execute_repost_task
from .search import execute_search_task
from .user import execute_user_task
from .dialogue import execute_dialogue_task